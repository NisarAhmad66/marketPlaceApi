const mongoose = require("mongoose");

mongoose
  .connect(
    "mongodb+srv://nisar:12345@cluster0.abu3s.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    {
      // useCreateIndex: true,
      useNewUrlParser: true,
      useUnifiedTopology: true,
      // useFindAndModify: false,
    }
  )
  .then(() => {
    console.log("connection is successfully....");
  })
  .catch((err) => {
    console.log(err.message);
  });
