const router = require("express").Router();
const admin = require("../model/admin");
var passwordHash = require("password-hash");
const req = require("express/lib/request");
const res = require("express/lib/response");

router.post("/create", async (req, res) => {
  try {
    let userExists = await admin.findOne({ email: req.body.email });
    if (userExists || userExists?.length > 0) {
      return res.status(400).json({
        success: false,
        message: "A user with this email is already registered",
      });
    }

    const newUser = new admin({
      email: req.body.email,
      password: passwordHash.generate(req.body.password),
      // confPassword: req.body.confPassword,
      status: req.body.status,
    });

    await newUser.save();
    res.status(200).json({
      success: true,
      message: "User registered successfully",
      data: newUser,
    });
  } catch (error) {
    console.log(error);
    res.status(400).json({
      success: false,
      message: "Something went wrong try again",
    });
  }
});

router.post("/login", async (req, res) => {
  console.log(req.body);
  try {
    let result = await admin.findOne({ email: req.body.email });
    console.log(result);
    if (result) {
      if (passwordHash.verify(req.body.password, result.password)) {
        console.log("yes...............................");
        // let jwtToken = jwt.sign({ _id: result._id }, process.env.privateKeyForLoginSignup);
        res.json({ result, status: 1, message: "Authorized" });
      } else {
        res.json({ status: 0, message: "Not Authorized" });
      }
    } else {
      res.json({ status: 0, message: "Not Authorized" });
    }
  } catch (error) {
    console.log(error);
    res.json({ status: 0, message: "Somthing went wrong" });
  }
});
router.post("/pass", async (req, res) => {
  try {
    let result = await admin.findOne({ email: req.body.email });
    // let message = "";
    let status = 0;
    console.log(result);
    if (result) {
      message = "email find";
      status = 1;
    } else {
      message = "something went wrong";
      status = 0;
    }

    res.json({ result, message, status });
  } catch (error) {
    res.json({ status: 0, message: "Something went wrong" });
  }
});

router.post("/updatePass/:id", async (req, res) => {
  let body = req.body;
  console.log(body);

  try {
    let result = await admin.findById(req.params.id);
    console.log(result);

    let response = await admin.findByIdAndUpdate(
      req.params.id,
      {
        password: passwordHash.generate(body.password),
      },
      { new: true }
    );
    console.log(response);
    res.json({ result, status: 1, message: "Password is Updated Successfully" });
  } catch (error) {
    res.json({ status: 0, message: "Something went wrong" });
  }
});

module.exports = router;
