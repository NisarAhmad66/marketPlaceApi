const router = require("express").Router();
const adminCategory = require("../model/adminCategory");

const req = require("express/lib/request");
const res = require("express/lib/response");

module.exports = router;
