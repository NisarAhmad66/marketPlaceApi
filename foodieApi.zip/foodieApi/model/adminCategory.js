const mongoose = require("mongoose");
const validator = require("validator");

const adminCategory = new mongoose.Schema({
  categoryName: {
    type: String,
    required: true,
  },
  status: {
    type: Boolean,
    default: true,
  },
});

module.exports = new mongoose.model("AdminCategory", adminCategory);
