const mongoose = require("mongoose");
const validator = require("validator");

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    validate(value) {
      if (!validator.isEmail(value)) {
        throw new Error("Email is InValid");
      }
    },
  },
  address: {
    type: String,
    required: true,
  },
  phone: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  // confPassword: {
  //   type: String,
  //   required: true,
  // },
  status: {
    type: Boolean,
    default: true,
  },
});

//we will create new collection
module.exports = new mongoose.model("UserRegistration", userSchema);

// module.exports = UserRegistration;
