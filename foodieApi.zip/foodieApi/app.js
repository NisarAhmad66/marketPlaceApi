const dotenv = require("dotenv");
dotenv.config();
const express = require("express"); //this is import express packge
// const cors = require("cors");
const { mongoose } = require("./db/connection"); // this is connection to database

// const macItemDetail = require("./routers/macItemDetails");
// const resturant = require("./routers/resturants");

const userRegistration = require("./router/user");
const admin = require("./router/admin");
const adminCategory = require("./router/adminCategory");
const app = express();
const port = 3000; // this is use to create the port
app.use(express.json({ limit: "50mb" }));

app.use("/user", userRegistration);
app.use("/admin", admin);
app.use("/admin", adminCategory);

// app.use("/macItemDetails", macItemDetails);
// app.use("/user", require("./routers/resturants"));

app.listen(process.env.PORT || 3000, () => {
  console.log(`Connection is setup at ${port}`);
});
